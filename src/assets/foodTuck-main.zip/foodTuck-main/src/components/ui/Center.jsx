import React from "react";
import "../../../src/index.css";
const Center = (props) => {
  return <div className="centeredText ">{props.children}</div>;
};

export default Center;
